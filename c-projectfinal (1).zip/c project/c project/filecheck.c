#include<stdio.h>
#include<string.h>
typedef struct
{
    char question[200];
    char option1[20];
    char option2[20];
    char option3[20];
    char option4[20];
    int rightoption;

} quiz;
int main()
{
    quiz s[50];
     FILE *fp;
     int i=0;
     fp=fopen("question.dat","rb+");
     
     while(fread(&s[i],sizeof(s[i]),1,fp)==1)
     {
        printf("ftell=%d\n",ftell(fp));
    
   printf("Q.%d)%s \n 1.\t%s \n 2.\t%s \n 3. \t%s \n 4. \t%s \n",i, s[i].question, s[i].option1, s[i].option2, s[i].option3, s[i].option4);
   i++;
//    if(i==14)
//     {
    //     strcpy(s[i].question,"what is the ASCII value of 9");
    //     strcpy(s[i].option1,"57");
    //     strcpy(s[i].option2,"58");
    //     strcpy(s[i].option3,"59");
    //     strcpy(s[i].option4,"54");
    //     s[i].rightoption=1;
    //     // printf("%s",s[i].option3);
    //     // printf("%d",i);
    //     fseek(fp,-1*sizeof(s[i]),SEEK_CUR);
    //     printf("ftell2=%d\n",ftell(fp));
    //     fwrite(&s[i],sizeof(s[i]),1,fp);
    //     break;
    // }

    //     if(i==5)
    // {
    //     strcpy(s[i].question,"The derivative of ln(e^x) is: ");

    //     // s[i].rightoption=2;
    //     // printf("%s",s[i].option3);
    //     // printf("%d",i);
    //     fseek(fp,-1*sizeof(s[i]),SEEK_CUR);
    //     printf("ftell2=%d\n",ftell(fp));
    //     fwrite(&s[i],sizeof(s[i]),1,fp);
    //     break;
    // }  
     }
     
     fclose(fp);
return 0;
}