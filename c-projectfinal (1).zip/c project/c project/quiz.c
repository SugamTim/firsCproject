#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

typedef struct
{
    char question[200];
    char option1[20];
    char option2[20];
    char option3[20];
    char option4[20];
    int rightoption;

} quiz;
// int random();
void play();
void takeInput();
void playQuiz();


// int random()
// {
//     srand(time(NULL));
//     int a = rand();
//     return a % 10;
// }

void play()
{
    int score = 0,n=0,i,choice,k;
    quiz q[100];
    FILE *fp;
    fp = fopen("question.dat", "rb");

   while(fread(&q[i], sizeof(q[i]), 1, fp)==1)
    {
        n++;
        i++;
    }
    int selected[n];
    for (i = 0; i < n; i++)
    {
        system("cls");
        system("color 3f");
        printf("Attempted question no's: ");
        k=0;
        while(k<i)
        {
            printf("%d ",selected[k]);
            k++;
        }
        printf("\n");
        printf("Choose any  distinct question no. from 1 to %d: ",n);
        scanf("%d",&choice);
        while ((choice<=0 || choice >n))
        {   
            printf("Invalid choice! please enter valid number:");
            scanf("%d",&choice);
        } 
        
        selected[i]=choice;
        choice--;
        int answer;
        printf("Q.%d)%s \n 1.\t%s \n 2.\t%s \n 3. \t%s \n 4. \t%s \n",i+1, q[choice].question, q[choice].option1, q[choice].option2, q[choice].option3, q[choice].option4);
            printf("\n\n\n\t\t\tMake a valid choice: ");
            fflush(stdin);
            scanf("%d", &answer);
            
        
        if (answer == q[choice].rightoption)
        {
            score++;
            system("cls");
            system("color 2f");
            printf("\n\n\n\t\tCONGRATS!\n");
        }
        else
        {
            system("color 4f");
            printf("\n\n\t\t\tThe right option is %d\n", q[choice].rightoption);
        }
        getch();
    }
    system("cls");
    system("color 2f");
    printf("\n\n\t\t Your score is %d.\n", score * 100);
    getch();
    fclose(fp);
}

void takeInput()
{
	int i;
    system("color 4b");
    FILE *fp;
    fp = fopen("question.dat", "ab");
    char check, temp;
    int n;
    system("cls");
    printf("\n\n\n\n\t\tHow many questions do you want to enter?\n ");
    fflush(stdin);
    scanf("%d", &n);
    quiz q[n];

    for ( i = 0; i < n; i++)
    {
        system("cls");
        fflush(stdin);
        printf("\n\n\nEnter the question: \n");
        fgets(q[i].question, 200, stdin);
        fflush(stdin);
        printf("Enter option 1: \n");
        gets(q[i].option1);
        fflush(stdin);
        printf("Enter option 2: \n");
        gets(q[i].option2);
        fflush(stdin);
        printf("Enter option 3: \n");
        gets(q[i].option3);
        fflush(stdin);
        printf("Enter option 4: \n");
        gets(q[i].option4);
        printf("Enter the correct option : \n");
        scanf("%d", &q[i].rightoption);

        fwrite(&q[i], sizeof(q[i]), 1, fp);
        fflush(stdin);
        system("pause");
       
    }
    fclose(fp);
}



void playQuiz()
{
    int flag;
    system("color 2f");
    system("cls");
    printf("\n\n\t\t\t\t\t\tGENERAL QUIZ\n");
    printf("\n\n\n\t\tPress 1 to add question.\n\t\tPress 2 to play\n");
    scanf("%d", &flag);

    if (flag == 1)
        takeInput();
    else
        play();
}

