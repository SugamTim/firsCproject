// #include<windows.h>
#include<stdio.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
#include"quiz.h"
#include"ticTacToe.h"
#include"quiz.c"
#include"ticTacToe.c"
int main()
{
    char usrchoice;
    int i;
    system("cls");
    system("color 4f");
    printf("\n\n\n\n\n\n\n\n\t\t\t\t\t  -----WELCOME TO THE PLAYSTATION-----");
    printf("\n\n\n\n\n\n\n\n  Press ENTER to Continue and  TAB to exit>>>>>>>>>");
    scanf("%c",&usrchoice);
    if(usrchoice=='\n')
    {
       printf("Enjoy your journey!!\n");
    }
    else if(usrchoice=='\t')
    {
        exit(0);
    }
    else
    {
        while(usrchoice!='\t' && usrchoice!='\n')
        {
        fflush(stdin);
        printf("Enter valid choice: ");
        scanf("%c",&usrchoice);

        }
    }

beginning:
    system("cls");
    system("color 5f");
    printf("\n\n\n\n\nEnter 1 for TIC-TAC-TOE\n\n\n\n");
    printf("\n\n\n\n\nEnter 2 for GENERAL-QUIZ\n\n\n\n");

    int flag;
    fflush(stdin);
    scanf("%d", &flag);
    switch (flag)
    {
  case 1:
        playTicTacToe();

        break;
    case 2:
        playQuiz();
        break;
    default:
        system("cls");
        system("color 4f");
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t !!!!!!!!!Sorry you broke the game!!!!!!!!!");
        getch();
    }
    system("cls");
    system("color 0c");
    printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\tWe are taking you to main menu");
    for(i=0;i<5;i++)
    {
        printf("..");
        Sleep(700);
    }
    goto beginning;
    
    return 0;
}
