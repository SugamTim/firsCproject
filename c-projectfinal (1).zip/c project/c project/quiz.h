#ifndef QUIZ_H
#define QUIZ_H

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include <ctype.h>

void playQuiz();

#endif