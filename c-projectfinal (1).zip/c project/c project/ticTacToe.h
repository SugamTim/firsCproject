#ifndef TICTACTOE_H
#define TICTACTOE_H

int checkWin(char[]);
void drawBoard(char[]);
void playTicTacToe();

#endif